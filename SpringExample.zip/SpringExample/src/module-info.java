module springExample {
	requires spring.context;
}