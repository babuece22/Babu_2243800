package sl.bean.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import sl.spring.com.Employee;

@Configuration
@ComponentScan("sl.spring.com")
public class BeanConfig {
	
/*	@Bean
	public Employee employeeObj() {
	
	Employee e = new Employee();
	e.setId(234);
	e.setEmployee("Babu");
	return e;	

} */
}
