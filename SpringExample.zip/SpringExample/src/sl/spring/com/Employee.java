package sl.spring.com;

public class Employee {
	
	public String employee;
	public int id;
	public String getEmployee() {
		return employee;
	}
	public void setEmployee(String employee) {
		this.employee = employee;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
return "employee" +employee +"id"+id;
		}

}
