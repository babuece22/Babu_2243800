package sl.spring.com;

import org.springframework.stereotype.Component;

@Component
public class Project {
	
	private int projectid;
	
	@Override
	public String toString() {
		
		return "Projectid" +projectid;
	}
}
