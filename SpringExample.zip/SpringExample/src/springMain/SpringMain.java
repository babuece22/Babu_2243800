package springMain;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import sl.bean.configuration.BeanConfig;
import sl.spring.com.Employee;
import sl.spring.com.Project;

public class SpringMain {

	public static void main(String[] args) {
		
		//---used for xml base--//
		//ApplicationContext context = new ClassPathXmlApplicationContext("/sl/bean/configuration/applicationContext.xml");
		
		//--Used for Annotation based java---//
		
		ApplicationContext context= new AnnotationConfigApplicationContext(BeanConfig.class);
		Project emp = (Project) context.getBean("Project");
		System.out.println(emp);
		
		
		System.out.println("working fine");
	}
}
